const crypto = require('crypto');

function buildRequestUrl(evt) {
  const q = evt.rawQueryString ? `?${evt.rawQueryString}` : '';
  return `https://${evt.requestContext.domainName}${evt.rawPath}${q}`;
}

function verifyV3(evt, appSecret) {
  const sig = evt.headers && (evt.headers['x-hubspot-signature-v3'] || evt.headers['X-HubSpot-Signature-V3']);
  const ts  = evt.headers && (evt.headers['x-hubspot-request-timestamp'] || evt.headers['X-HubSpot-Request-Timestamp']);
  if (!sig || !ts) return false;

  const tsNum = Number(ts);
  const skew = Math.abs(Date.now() - tsNum);
  if (!tsNum || skew > 5 * 60 * 1000) return false;

  const method = (evt.requestContext && evt.requestContext.http && evt.requestContext.http.method) || 'POST';
  const url = buildRequestUrl(evt);
  const body = evt.body || '';

  const base = '' + method + url + body + ts;
  const expected = crypto.createHmac('sha256', appSecret).update(base, 'utf8').digest('base64');

  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig));
  } catch (e) {
    return false;
  }
}

exports.handler = async function(event) {
  const secret = process.env.HS_APP_SECRET;
  const ok = secret && verifyV3(event, secret);

  if (!ok) {
    console.log('✖ invalid hubspot signature', (event.requestContext && event.requestContext.http && event.requestContext.http.method) || 'POST', event.rawPath);
    return { statusCode: 401, body: 'invalid signature' };
  }

  console.log('✅ hubspot webhook verified', (event.requestContext && event.requestContext.http && event.requestContext.http.method) || 'POST', event.rawPath);
  return { statusCode: 200, body: 'ok' };
};
