// index.js (CommonJS, Node 20)
// expects env: HS_TOKEN, GHCR_USER, GHCR_PAT
const fetch = globalThis.fetch || require('node-fetch');
const HUBSPOT = 'https://api.hubapi.com';
const H = (msg, extra={}) => console.log(JSON.stringify({ ts: new Date().toISOString(), ...msg, ...extra }));

exports.handler = async (event) => {
  try {
    // Authorizer already enforces X-Edge-Auth; we enforce pairing token here.
    const token = event?.headers?.['x-download-token'] || event?.headers?.['X-Download-Token'];
    if (!token) {
      H({ level: 'warn', type: 'lease_error', where: 'request', detail: 'missing x-download-token' });
      return resp(401, { error: 'missing token' });
    }

    // Find contact by download_token
    const contact = await findContactByToken(token);
    if (!contact) {
      H({ level: 'info', type: 'lease_denied', reason: 'invalid-token' });
      return resp(403, { error: 'invalid token' });
    }

    const id = contact.id;
    const props = contact.properties || {};
    const email = props.email || '';
    const enabled = normalizeBool(props.download_enabled); // "true"/"false" -> boolean or null

    if (enabled === false) {
      H({ level: 'info', type: 'lease_denied', reason: 'disabled', contactId: id, email: mask(email) });
      return resp(403, { error: 'disabled' });
    }

    H({ level: 'info', type: 'lease_ok', contactId: id, email: mask(email) });
    return resp(200, {
      ServerURL: 'ghcr.io',
      Username: process.env.GHCR_USER || '',
      Secret: process.env.GHCR_PAT || '',
    });
  } catch (err) {
    H({ level: 'error', type: 'lease_error', where: 'unexpected', detail: String(err && err.message || err) });
    return resp(500, { error: 'internal' });
  }
};

function normalizeBool(v) {
  if (v == null) return true;              // treat missing as enabled (or flip to false if you prefer stricter)
  if (typeof v === 'boolean') return v;
  const s = String(v).toLowerCase().trim();
  if (s === 'true' || s === 'yes' || s === '1') return true;
  if (s === 'false' || s === 'no' || s === '0') return false;
  return true; // default allow
}

function mask(email) {
  if (!email || !email.includes('@')) return '';
  const [u, d] = email.split('@');
  return (u[0] || '') + '***@' + d;
}

async function findContactByToken(token) {
  const res = await fetch(`${HUBSPOT}/crm/v3/objects/contacts/search`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${process.env.HS_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      limit: 1,
      filterGroups: [{ filters: [{ propertyName: 'download_token', operator: 'EQ', value: token }] }],
      properties: ['email', 'download_enabled', 'download_token'],
    }),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    console.log(JSON.stringify({ level: 'error', type: 'lease_error', where: 'hubspot-search', status: res.status, body: text }));
    // Map HubSpot failure to 502, not 500
    throw new Error(`hubspot-search ${res.status}`);
  }
  const data = await res.json();
  return data?.results?.[0] || null;
}

function resp(status, body) {
  return { statusCode: status, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) };
}